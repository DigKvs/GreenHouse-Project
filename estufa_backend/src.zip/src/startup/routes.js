const express = require('express');
const sensor = require('../routes/Sensor');
const online = require('../routes/OnlinePage');


module.exports = function (app) {
    app.use(express.json());
    app.use('/api/', sensor);
    app.use('/api/', online);
}