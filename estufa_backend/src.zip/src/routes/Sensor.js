const express = require('express');
const SensorsController = require('../controller/SensorsController');
const router = express.Router();
router
    .get('/sensors', SensorsController.getAllPeople)
    .get('/sensors/:id', SensorsController.getById)
    .post('/sensors', SensorsController.create)
    .put('/sensors/:id', SensorsController.updateById)
    .delete('/sensors/:id', SensorsController.deleteById)
module.exports = router;